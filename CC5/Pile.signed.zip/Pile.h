#ifndef Pile_hpp
#define Pile_hpp

#include <ostream>

// Forward declarations
template <typename T> class Pile;
template <typename T> std::ostream& operator<<( std::ostream& os,
                                                const Pile<T>& p);

// Type Pile
template <typename T>
class Pile {
   friend std::ostream& operator<< <>( std::ostream& os,
                                       const Pile<T>& p);

public:
   using value_type = T;
   using pointer = value_type*;
   using reference = value_type&;
   using const_reference = const value_type&;

private:
   pointer donnees;
   size_t taille;
   const size_t CAPACITE;

public:
   Pile(size_t _CAPACITE)
   : CAPACITE(_CAPACITE), taille(0)
   {
      // Allocation de la mémoire
      donnees = (pointer) ::operator new(CAPACITE * sizeof(value_type));
   }

   ~Pile()
   {
      // Parcours la Pile, détruit chaque objets
      for(size_t i = 0; i < taille; ++i) {
         donnees[i].~value_type();
      }
      ::operator delete(donnees);
   }

   Pile(const Pile& other)
   : CAPACITE(other.CAPACITE), taille(0)
   {
      // Allocation de la mémoire
      donnees = (pointer) ::operator new(CAPACITE * sizeof(value_type));
      
      // Copie des objets de la Pile other
      for (size_t i = 0; i < other.taille; i++) {
         new (donnees + taille++) value_type(other.donnees[i]);
      }
   }

   void empiler(const value_type& v)
   {
      // Crée/empile un objet de type value_type dans la pile
      new (donnees + taille++) value_type(v);
   }

   void depiler()
   {
      // Détruit/dépile un objet de type value_type dans la pile
      donnees[--taille].~value_type();
   }

   const_reference sommet() const
   {
      // Retourne l'objet du haut de la pile
      return this->donnees[taille-1];
   }
};

// ne pas modifier
template <typename T>
std::ostream& operator<<( std::ostream& os,
                          const Pile<T>& p)
{
   os << "Pile(" << p.taille << "/" << p.CAPACITE << "): ";
   size_t i = p.taille;
   while(i > 0)
      os << p.donnees[--i] << " ";
   return os;
}

#endif /* Pile_hpp */